﻿using System.Text;
using LessonA.DayOne;
using LessonA.Day_Two;
using LessonA.DayThree;
using LessonA.DayFour;
/*
ValueTypeLesson.TestValueTypes();  //NO need objects to call since it is a Static method
ValueTypeLesson.TestMethod();*/

/*Console.WriteLine("Enter the first Parameter");
String x = Console.ReadLine();
Console.WriteLine("Enter the second Parameter");
String y = Console.ReadLine();

int firstValue = int.Parse(x);
int secondValue = int.Parse(y);
int addresult = Calculator.Add(firstValue, secondValue);
Console.WriteLine(addresult);

int subresult = Calculator.Subract(firstValue, secondValue);
Console.WriteLine(subresult);

int multiplyresult = Calculator.Multiply(firstValue, secondValue);
Console.WriteLine(multiplyresult);

int divideresult = Calculator.Divide(firstValue, secondValue);
Console.WriteLine(divideresult);*/

//Statements.TestOne();

//NamePassword.DoLogin();

/*BoxTester.TestOne();
BoxTester.TestTwo();
BoxTester.TestThree();*/

//VechileTester.TestOne();

//MessageTester.TestOne();

//NestedTry.NestedTryDemo(); //not run check!!

TestEmployee.TestOne();
TestEnum.TestMovieRating();